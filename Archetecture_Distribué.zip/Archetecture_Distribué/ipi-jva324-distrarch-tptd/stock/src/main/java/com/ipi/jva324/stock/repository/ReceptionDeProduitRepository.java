package com.ipi.jva324.stock.repository;

import com.ipi.jva324.stock.model.ReceptionDeProduit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReceptionDeProduitRepository extends JpaRepository<ReceptionDeProduit,Long> {

}
