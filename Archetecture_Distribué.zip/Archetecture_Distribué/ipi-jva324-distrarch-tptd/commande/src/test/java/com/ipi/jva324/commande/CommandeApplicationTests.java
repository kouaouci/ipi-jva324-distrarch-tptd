package com.ipi.jva324.commande;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommandeApplicationTests {

	@Test
	void contextLoads() {
	}

}
